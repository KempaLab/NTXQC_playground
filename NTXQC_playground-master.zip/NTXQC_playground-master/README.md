# NTXQC_playground

## Introduction

Welcome to the current stage of our NTXQC project. I added all the files (including input files)
here since we are still working on how to import and process the data. 
Later on this will be removed.

One note: this is not the R package! Treat this repo like a regular MTXQC-analgue thing. 

### How to use it

Use the green button and download a zip-file. This gives you access to all files. 

If you would like to contribute to this repository use the green button and clone
the project into a new RStudio project (Rstudio, New project, version control).

